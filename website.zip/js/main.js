window.addEventListener('load', function() {
    document.getElementById('loader').classList.add('loaded');
});

